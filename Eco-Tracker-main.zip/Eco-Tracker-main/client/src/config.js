const config = {
    //API_URL : "http://localhost:5000",
    API_URL : "https://visualuminate.vercel.app", // for production
}

export default config;
